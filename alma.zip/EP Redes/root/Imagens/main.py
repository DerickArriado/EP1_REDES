import tkinter as tk
from drawing_app import DrawingApp

if __name__ == "__main__":
    root = tk.Tk()
    app = DrawingApp(root)
    root.mainloop()
